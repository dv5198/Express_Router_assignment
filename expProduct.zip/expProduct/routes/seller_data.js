const seller=[{
    "id": 1,
    "name": "ABC",
    "product_id": [1,3,5]
  }, {
    "id": 2,
    "name": "PQR",
    "product_id": [2.5]
  }, {
    "id": 3,
    "name": "XYZ",
    "product_id": [1,3,4]
  }, {
    "id": 4,
    "name": "MNO",
    "product_id": [4]
  }, {
    "id": 5,
    "name": "DEF",
    "product_id": [1,5]
  }]
module.exports=seller  