
const prod=[{
    "id": 1,
    "product_title": "Curry Powder Madras",
    "price": 29,
    "category": ["masala"],
    "company  id": 1,
    "seller id": []
  }, {
    "id": 2,
    "product_title": "Beef - Salted",
    "price": 57,
    "category": ["Spices","Salt"],
    "company  id": 2,
    "seller id": [1,2,]
  }, {
    "id": 3,
    "product_title": "Snapple Lemon Tea",
    "price": 32,
    "category": ["Tea"],
    "company  id": 3,
    "seller id": [1]
  }, {
    "id": 4,
    "product_title": "Orange Roughy 6/8 Oz",
    "price": 21,
    "category": ["drinks","food"],
    "company  id": 4,
    "seller id": [1,2],
  }, {
    "id": 5,
    "product_title": "Bread Foccacia Whole",
    "price": 32,
    "category": ["Edible","bread"],
    "company  id": 5,
    "seller id": [4,3]
  }]

  module.exports = product