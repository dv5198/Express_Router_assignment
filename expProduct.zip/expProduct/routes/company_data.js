const cmp=[{
    "id": 1,
    "name": "Dazzlesphere",
    "product_id": [1,3,4,5]
  }, {
    "id": 2,
    "name": "Meembee",
    "product_id": [2.5]
  }, {
    "id": 3,
    "name": "Wordpedia",
    "product_id": [1]
  }, {
    "id": 4,
    "name": "Shufflester",
    "product_id": [2,4]
  }, {
    "id": 5,
    "name": "Bubbletube",
    "product_id": [3,1,5]
  }]
module.exports=cmp  